# ABC Pronunciation Game — Android APK

This Android project wraps the live GitHub Pages game in a native Android WebView.

Game URL:
https://ummayhossainmunna-cpu.github.io/abc-pronunciation-game/

## Features

- Portrait Android app
- JavaScript enabled
- HTTPS game loaded directly from GitHub Pages
- Microphone permission support for pronunciation
- Android back button support
- GitHub Actions workflow for building an APK

## Build with Android Studio

1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.
6. To make an APK: Build → Build APK(s).

The debug APK will be generated at:

app/build/outputs/apk/debug/app-debug.apk

## Build APK automatically with GitHub

The included workflow is:
.github/workflows/build-apk.yml

After uploading this project to a GitHub repository:
1. Open the repository.
2. Open Actions.
3. Select "Build Android APK".
4. Run workflow.
5. When it finishes, open the workflow run.
6. Download the artifact named "ABC-Pronunciation-Game-APK".

## Important

The app currently loads the live website from GitHub Pages. If the website is updated, the installed app will show the updated game when it loads again, without rebuilding the APK.
